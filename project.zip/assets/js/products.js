import { getState, subscribe, loadProducts, addProduct, updateProduct, deleteProduct } from './state.js';
import { addToCart } from './state.js';
import { openModal, closeModal, toast, fmt } from './ui.js';

const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

const els = {
  search:   $('#search'),
  category: $('#filter-category'),
  stock:    $('#filter-stock'),
  tbody:    $('#products-tbody'),
  empty:    $('#products-empty'),
  count:    $('#products-count'),
  form:     $('#product-form'),
  modalTitle: $('#product-modal-title'),
  confirmDelete: $('#confirm-delete-form'),
  confirmDeleteInput: $('#confirm-delete-input'),
  confirmDeleteName:  $('#confirm-delete-name'),
};

let editingId = null;
let deletingId = null;

/* ============ Render ============ */
function render() {
  const { products, loading } = getState();
  const q   = els.search.value.trim().toLowerCase();
  const cat = els.category.value;
  const st  = els.stock.value;

  const filtered = products.filter(p => {
    if (q && !(p.name_ar.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q))) return false;
    if (cat && p.category !== cat) return false;
    if (st === 'in'  && !(p.stock > 0)) return false;
    if (st === 'low' && !(p.stock > 0 && p.stock < 10)) return false;
    if (st === 'out' && p.stock !== 0) return false;
    return true;
  });

  els.count.textContent = `${filtered.length} صنف`;
  els.tbody.innerHTML = filtered.map(rowHTML).join('');
  els.empty.classList.toggle('hidden', filtered.length > 0 || loading);

  // populate category filter once
  if (els.category.options.length <= 1) {
    const cats = [...new Set(products.map(p => p.category))];
    cats.forEach(c => {
      const o = document.createElement('option');
      o.value = c; o.textContent = c;
      els.category.appendChild(o);
    });
  }
}

function rowHTML(p) {
  const badge =
    p.stock === 0      ? '<span class="badge badge-out">نفدت</span>'
  : p.stock < 10       ? `<span class="badge badge-low">منخفض · ${p.stock}</span>`
  :                      `<span class="badge badge-ok">${p.stock}</span>`;
  const thumb = p.image_url
    ? `<img src="${p.image_url}" alt="" style="width:36px;height:36px;object-fit:cover;border:1px solid var(--border);">`
    : `<div style="width:36px;height:36px;background:var(--bg-1);border:1px solid var(--border);display:grid;place-items:center;color:var(--fg-4);font-family:var(--font-mono);font-size:10px;">IMG</div>`;

  return `
    <tr data-id="${p.id}">
      <td>${thumb}</td>
      <td class="mono muted">${escape(p.sku)}</td>
      <td style="font-weight:600;">${escape(p.name_ar)}</td>
      <td>${escape(p.category)}</td>
      <td class="mono">${fmt.money(p.wholesale_price)}</td>
      <td class="mono">${p.carton_qty}</td>
      <td>${badge}</td>
      <td>
        <div class="row gap-2">
          <button class="btn btn-sm btn-primary" data-act="cart" ${p.stock===0?'disabled':''}>+ سلة</button>
          <button class="btn btn-sm" data-act="edit">تعديل</button>
          <button class="btn btn-sm btn-danger" data-act="del">حذف</button>
        </div>
      </td>
    </tr>`;
}

function escape(s='') { return s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]); }

/* ============ Row actions (delegated) ============ */
els.tbody.addEventListener('click', (e) => {
  const btn = e.target.closest('button[data-act]');
  if (!btn) return;
  const id = btn.closest('tr').dataset.id;
  const p  = getState().products.find(x => x.id === id);
  if (!p) return;

  if (btn.dataset.act === 'cart') {
    addToCart(p, 1);
    toast(`تمت إضافة ${p.name_ar} إلى السلة`, 'success');
  }
  if (btn.dataset.act === 'edit') openEditModal(p);
  if (btn.dataset.act === 'del')  openDeleteModal(p);
});

/* ============ Filters ============ */
let searchTimer;
els.search.addEventListener('input', () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(render, 80);
});
els.category.addEventListener('change', render);
els.stock.addEventListener('change', render);

/* ============ CRUD: Create / Update ============ */
$('#btn-add-product').addEventListener('click', () => {
  editingId = null;
  els.modalTitle.textContent = 'إضافة صنف جديد';
  els.form.reset();
  openModal('product-modal');
});

function openEditModal(p) {
  editingId = p.id;
  els.modalTitle.textContent = 'تعديل الصنف';
  els.form.name_ar.value         = p.name_ar;
  els.form.sku.value             = p.sku;
  els.form.category.value        = p.category;
  els.form.wholesale_price.value = p.wholesale_price;
  els.form.carton_qty.value      = p.carton_qty;
  els.form.stock.value           = p.stock;
  els.form.image_url.value       = p.image_url || '';
  openModal('product-modal');
}

els.form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = els.form.querySelector('button[type=submit]');
  btn.disabled = true; btn.textContent = 'جاري الحفظ…';

  const row = {
    name_ar:         els.form.name_ar.value.trim(),
    sku:             els.form.sku.value.trim().toUpperCase(),
    category:        els.form.category.value.trim(),
    wholesale_price: Number(els.form.wholesale_price.value),
    carton_qty:      Number(els.form.carton_qty.value),
    stock:           Number(els.form.stock.value),
    image_url:       els.form.image_url.value.trim(),
  };

  try {
    if (editingId) {
      await updateProduct(editingId, row);
      toast('تم تحديث الصنف', 'success');
    } else {
      await addProduct(row);
      toast('تمت إضافة الصنف', 'success');
    }
    closeModal('product-modal');
  } catch (err) {
    toast(err.message || 'فشل الحفظ', 'error');
  } finally {
    btn.disabled = false; btn.textContent = 'حفظ';
  }
});

/* ============ CRUD: Delete (strict confirmation) ============ */
function openDeleteModal(p) {
  deletingId = p.id;
  els.confirmDeleteName.textContent = p.name_ar;
  els.confirmDeleteInput.value = '';
  openModal('delete-modal');
}

els.confirmDelete.addEventListener('submit', async (e) => {
  e.preventDefault();
  if (els.confirmDeleteInput.value.trim() !== 'احذف') {
    toast('اكتب "احذف" بالضبط للتأكيد', 'error');
    return;
  }
  try {
    await deleteProduct(deletingId);
    closeModal('delete-modal');
    toast('تم حذف الصنف', 'success');
  } catch (err) {
    toast(err.message || 'فشل الحذف', 'error');
  }
});

/* ============ Boot ============ */
subscribe(render);
loadProducts().catch(err => toast('تعذر الاتصال بقاعدة البيانات: ' + err.message, 'error'));
