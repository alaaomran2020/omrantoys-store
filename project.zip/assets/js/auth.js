import { signIn, signUp, getUser, IS_MOCK } from './supabase.js';
import { toast } from './ui.js';

const $ = (s) => document.querySelector(s);

async function guard() {
  const u = await getUser();
  if (u) window.location.replace('./dashboard.html');
}
guard();

// Tab switching
const tabLogin = $('#tab-login');
const tabReg   = $('#tab-register');
const formLogin = $('#form-login');
const formReg   = $('#form-register');

function switchTo(mode) {
  const isLogin = mode === 'login';
  tabLogin.classList.toggle('active', isLogin);
  tabReg.classList.toggle('active', !isLogin);
  formLogin.classList.toggle('hidden', !isLogin);
  formReg.classList.toggle('hidden', isLogin);
}
tabLogin.addEventListener('click', () => switchTo('login'));
tabReg.addEventListener('click', () => switchTo('register'));

// Login
formLogin.addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = formLogin.querySelector('button[type=submit]');
  btn.disabled = true; btn.textContent = 'جاري الدخول…';
  try {
    const email = formLogin.email.value.trim();
    const pass  = formLogin.password.value;
    await signIn(email, pass);
    toast('تم تسجيل الدخول بنجاح', 'success');
    setTimeout(() => window.location.replace('./dashboard.html'), 400);
  } catch (err) {
    toast(err.message || 'فشل تسجيل الدخول', 'error');
    btn.disabled = false; btn.textContent = 'دخول';
  }
});

// Register
formReg.addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = formReg.querySelector('button[type=submit]');
  btn.disabled = true; btn.textContent = 'جاري إنشاء الحساب…';
  try {
    await signUp({
      email:    formReg.email.value.trim(),
      password: formReg.password.value,
      company:  formReg.company.value.trim(),
      phone:    formReg.phone.value.trim(),
    });
    toast('تم إنشاء الحساب. تفقد بريدك للتفعيل.', 'success');
    setTimeout(() => window.location.replace('./dashboard.html'), 600);
  } catch (err) {
    toast(err.message || 'فشل إنشاء الحساب', 'error');
    btn.disabled = false; btn.textContent = 'إنشاء حساب الجملة';
  }
});

// Mock banner
if (IS_MOCK) $('#mock-banner')?.classList.remove('hidden');
