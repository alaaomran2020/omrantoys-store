/**
 * Supabase client + Auth wrapper
 * -------------------------------
 * REPLACE the two placeholders below with your project credentials,
 * available at: https://app.supabase.com/project/_/settings/api
 *
 * The file is intentionally framework-free (Vanilla JS + ESM CDN)
 * so it drops into any static hosting (Netlify / Vercel / GH Pages).
 */

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.0';

const SUPABASE_URL      = window.__ENV__?.SUPABASE_URL      || 'https://YOUR-PROJECT.supabase.co';
const SUPABASE_ANON_KEY = window.__ENV__?.SUPABASE_ANON_KEY || 'YOUR-ANON-KEY';

// If credentials are missing we fall back to a mock so the prototype
// stays fully interactive during design review.
export const IS_MOCK = SUPABASE_URL.includes('YOUR-PROJECT');

export const supabase = IS_MOCK
  ? createMockClient()
  : createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: { persistSession: true, autoRefreshToken: true },
    });

/* ============ Auth helpers ============ */
export async function signIn(email, password) {
  if (IS_MOCK) return mockAuth('signIn', email);
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data;
}

export async function signUp({ email, password, company, phone }) {
  if (IS_MOCK) return mockAuth('signUp', email, { company, phone });
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: { data: { company, phone, role: 'wholesale_client' } },
  });
  if (error) throw error;
  return data;
}

export async function signOut() {
  if (IS_MOCK) { localStorage.removeItem('omran_mock_user'); return; }
  await supabase.auth.signOut();
}

export async function getUser() {
  if (IS_MOCK) {
    const raw = localStorage.getItem('omran_mock_user');
    return raw ? JSON.parse(raw) : null;
  }
  const { data } = await supabase.auth.getUser();
  return data?.user || null;
}

/* ============ MOCK client (design-time) ============ */
function createMockClient() {
  const store = {
    products: JSON.parse(localStorage.getItem('omran_mock_products') || 'null') || seedProducts(),
    cart:     JSON.parse(localStorage.getItem('omran_mock_cart') || '[]'),
  };
  const persist = () => {
    localStorage.setItem('omran_mock_products', JSON.stringify(store.products));
    localStorage.setItem('omran_mock_cart', JSON.stringify(store.cart));
  };

  return {
    __mock: true,
    from(table) {
      return {
        select: async () => ({ data: store[table] || [], error: null }),
        insert: async (row) => {
          const item = { id: crypto.randomUUID(), created_at: new Date().toISOString(), ...row };
          store[table].push(item);
          persist();
          return { data: [item], error: null };
        },
        update: async (patch) => ({ __chain: 'update', patch, table, store, persist }),
        delete: async () => ({ __chain: 'delete', table, store, persist }),
        eq(col, val) {
          const chain = this;
          return {
            async select() {
              return { data: store[table].filter(r => r[col] === val), error: null };
            },
            async update(patch) {
              store[table] = store[table].map(r => r[col] === val ? { ...r, ...patch } : r);
              persist();
              return { data: store[table].filter(r => r[col] === val), error: null };
            },
            async delete() {
              store[table] = store[table].filter(r => r[col] !== val);
              persist();
              return { data: null, error: null };
            },
          };
        },
      };
    },
    auth: {
      signInWithPassword: async ({ email }) => mockAuth('signIn', email),
      signUp: async ({ email, options }) => mockAuth('signUp', email, options?.data),
      signOut: async () => { localStorage.removeItem('omran_mock_user'); return { error: null }; },
      getUser: async () => {
        const raw = localStorage.getItem('omran_mock_user');
        return { data: { user: raw ? JSON.parse(raw) : null } };
      },
    },
  };
}

function mockAuth(op, email, extra = {}) {
  const user = {
    id: 'mock-' + email,
    email,
    user_metadata: { company: extra.company || 'شركة تجريبية', ...extra },
  };
  localStorage.setItem('omran_mock_user', JSON.stringify(user));
  return { user, session: { access_token: 'mock' } };
}

function seedProducts() {
  return [
    { id: 'p1', sku: 'TOY-001', name_ar: 'دبدوب فرو ناعم 40 سم', category: 'دباديب', wholesale_price: 45, carton_qty: 24, stock: 18, image_url: '' },
    { id: 'p2', sku: 'TOY-002', name_ar: 'سيارة سباق ريموت كنترول', category: 'سيارات', wholesale_price: 85, carton_qty: 12, stock: 6,  image_url: '' },
    { id: 'p3', sku: 'TOY-003', name_ar: 'مكعبات بناء 120 قطعة', category: 'تعليمية', wholesale_price: 32, carton_qty: 20, stock: 45, image_url: '' },
    { id: 'p4', sku: 'TOY-004', name_ar: 'دمية باربي كلاسيكية', category: 'دمى', wholesale_price: 55, carton_qty: 18, stock: 0,  image_url: '' },
    { id: 'p5', sku: 'TOY-005', name_ar: 'مسدس فقاعات صابون', category: 'ألعاب خارجية', wholesale_price: 18, carton_qty: 36, stock: 92, image_url: '' },
    { id: 'p6', sku: 'TOY-006', name_ar: 'بازل خشبي 500 قطعة', category: 'تعليمية', wholesale_price: 42, carton_qty: 15, stock: 22, image_url: '' },
    { id: 'p7', sku: 'TOY-007', name_ar: 'طقم مطبخ للأطفال', category: 'دمى', wholesale_price: 68, carton_qty: 10, stock: 8,  image_url: '' },
    { id: 'p8', sku: 'TOY-008', name_ar: 'كرة قدم مطاطية مقاس 5', category: 'ألعاب خارجية', wholesale_price: 25, carton_qty: 30, stock: 60, image_url: '' },
  ];
}
