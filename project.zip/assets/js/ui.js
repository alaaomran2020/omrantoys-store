// tiny UI helpers — toast + modal + drawer + money formatting

let toastRoot;
export function toast(msg, kind = '') {
  if (!toastRoot) {
    toastRoot = document.createElement('div');
    toastRoot.className = 'toast-stack';
    document.body.appendChild(toastRoot);
  }
  const el = document.createElement('div');
  el.className = 'toast ' + kind;
  el.textContent = msg;
  toastRoot.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateY(4px)'; el.style.transition = 'all 160ms'; }, 2600);
  setTimeout(() => el.remove(), 2900);
}

export function openModal(id)  { document.getElementById(id)?.classList.add('open'); }
export function closeModal(id) { document.getElementById(id)?.classList.remove('open'); }

export function openDrawer(id) {
  document.getElementById(id)?.classList.add('open');
  document.getElementById(id + '-backdrop')?.classList.add('open');
}
export function closeDrawer(id) {
  document.getElementById(id)?.classList.remove('open');
  document.getElementById(id + '-backdrop')?.classList.remove('open');
}

export const fmt = {
  money: (n) => new Intl.NumberFormat('ar-SA', { minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(n) + ' ر.س',
  num:   (n) => new Intl.NumberFormat('ar-SA').format(n),
};

// Delegated dismissers for all [data-close-modal] / [data-close-drawer] triggers
document.addEventListener('click', (e) => {
  const m = e.target.closest('[data-close-modal]');
  if (m) closeModal(m.dataset.closeModal);
  const d = e.target.closest('[data-close-drawer]');
  if (d) closeDrawer(d.dataset.closeDrawer);
  // backdrop click
  if (e.target.classList.contains('modal-backdrop')) e.target.classList.remove('open');
  if (e.target.classList.contains('drawer-backdrop')) {
    e.target.classList.remove('open');
    const id = e.target.id.replace('-backdrop','');
    document.getElementById(id)?.classList.remove('open');
  }
});

// ESC closes any open overlay
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-backdrop.open, .drawer-backdrop.open, .drawer.open')
      .forEach(el => el.classList.remove('open'));
  }
});
