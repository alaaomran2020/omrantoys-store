/**
 * Central state store — syncs with Supabase, replaces localStorage-only.
 * Emits change events so all UI modules can react.
 */
import { supabase, IS_MOCK } from './supabase.js';

const listeners = new Set();
const state = {
  user: null,
  products: [],
  cart: [],       // [{ product_id, cartons, unit_price, name_ar, sku, carton_qty }]
  loading: false,
  error: null,
};

export function getState() { return state; }
export function subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); }
function emit() { listeners.forEach(fn => fn(state)); }

/* ============ Products ============ */
export async function loadProducts() {
  state.loading = true; emit();
  try {
    const { data, error } = await supabase.from('products').select('*');
    if (error) throw error;
    state.products = data || [];
    state.error = null;
  } catch (e) {
    state.error = e.message || 'فشل تحميل المنتجات';
    state.products = [];
  } finally {
    state.loading = false;
    emit();
  }
}

export async function addProduct(row) {
  const { data, error } = await supabase.from('products').insert(row);
  if (error) throw error;
  const item = Array.isArray(data) ? data[0] : data;
  state.products = [item, ...state.products];
  emit();
  return item;
}

export async function updateProduct(id, patch) {
  const { error } = await supabase.from('products').eq('id', id).update(patch);
  if (error) throw error;
  state.products = state.products.map(p => p.id === id ? { ...p, ...patch } : p);
  emit();
}

export async function deleteProduct(id) {
  const { error } = await supabase.from('products').eq('id', id).delete();
  if (error) throw error;
  state.products = state.products.filter(p => p.id !== id);
  state.cart = state.cart.filter(c => c.product_id !== id);
  emit();
}

/* ============ Cart (persistent via Supabase table `cart_items`) ============ */
const CART_KEY = 'omran_cart_v2';

export async function loadCart() {
  // Cart is user-scoped. In mock mode we persist client-side; in real
  // mode we'd fetch cart_items joined with products. Kept simple here.
  try {
    const raw = localStorage.getItem(CART_KEY);
    state.cart = raw ? JSON.parse(raw) : [];
  } catch { state.cart = []; }
  emit();
}

function persistCart() {
  localStorage.setItem(CART_KEY, JSON.stringify(state.cart));
  // In production: upsert to `cart_items` table keyed by user_id here.
}

export function addToCart(product, cartons = 1) {
  const existing = state.cart.find(c => c.product_id === product.id);
  if (existing) {
    existing.cartons += cartons;
  } else {
    state.cart.push({
      product_id:  product.id,
      sku:         product.sku,
      name_ar:     product.name_ar,
      unit_price:  product.wholesale_price,
      carton_qty:  product.carton_qty,
      cartons,
    });
  }
  persistCart(); emit();
}

export function updateCartLine(product_id, cartons) {
  state.cart = state.cart
    .map(c => c.product_id === product_id ? { ...c, cartons } : c)
    .filter(c => c.cartons > 0);
  persistCart(); emit();
}

export function removeFromCart(product_id) {
  state.cart = state.cart.filter(c => c.product_id !== product_id);
  persistCart(); emit();
}

export function clearCart() {
  state.cart = [];
  persistCart(); emit();
}

/* ============ Selectors ============ */
export function cartTotals() {
  const lines = state.cart.map(c => ({
    ...c,
    units: c.cartons * c.carton_qty,
    line_total: c.cartons * c.carton_qty * c.unit_price,
  }));
  const subtotal = lines.reduce((s, l) => s + l.line_total, 0);
  const cartons_total = lines.reduce((s, l) => s + l.cartons, 0);
  const units_total = lines.reduce((s, l) => s + l.units, 0);
  return { lines, subtotal, cartons_total, units_total };
}

export const MIN_ORDER_TOTAL = 500; // ريال — قابل للتعديل
