import { getState, subscribe, loadCart, updateCartLine, removeFromCart, clearCart, cartTotals, MIN_ORDER_TOTAL } from './state.js';
import { openDrawer, closeDrawer, toast, fmt, openModal, closeModal } from './ui.js';

const $ = (s) => document.querySelector(s);

const els = {
  toggle:  $('#cart-toggle'),
  badge:   $('#cart-badge'),
  body:    $('#cart-body'),
  empty:   $('#cart-empty'),
  totals:  $('#cart-totals'),
  min:     $('#cart-min-warning'),
  checkout: $('#cart-checkout'),
};

function render() {
  const { lines, subtotal, cartons_total, units_total } = cartTotals();

  // Badge
  els.badge.textContent = cartons_total;
  els.badge.classList.toggle('hidden', cartons_total === 0);

  // Empty
  els.empty.classList.toggle('hidden', lines.length > 0);
  els.body.classList.toggle('hidden', lines.length === 0);
  els.totals.classList.toggle('hidden', lines.length === 0);

  // Lines
  els.body.innerHTML = lines.map(lineHTML).join('');

  // Totals
  $('#t-subtotal').textContent = fmt.money(subtotal);
  $('#t-cartons').textContent  = cartons_total;
  $('#t-units').textContent    = fmt.num(units_total);

  const belowMin = subtotal > 0 && subtotal < MIN_ORDER_TOTAL;
  els.min.classList.toggle('hidden', !belowMin);
  if (belowMin) {
    els.min.textContent = `الحد الأدنى للطلب ${fmt.money(MIN_ORDER_TOTAL)} — تبقى ${fmt.money(MIN_ORDER_TOTAL - subtotal)}`;
  }
  els.checkout.disabled = belowMin || lines.length === 0;
}

function lineHTML(l) {
  return `
    <div class="cart-line" data-id="${l.product_id}">
      <div style="display:flex;justify-content:space-between;gap:12px;">
        <div style="min-width:0;">
          <div style="font-weight:600;">${escape(l.name_ar)}</div>
          <div class="mono muted" style="font-size:11px;margin-top:2px;">${escape(l.sku)} · ${fmt.money(l.unit_price)} / قطعة</div>
        </div>
        <button class="btn btn-sm btn-ghost" data-act="remove" title="حذف">✕</button>
      </div>
      <div style="display:flex;align-items:center;justify-content:space-between;margin-top:10px;gap:8px;">
        <div class="qty">
          <button class="qty-btn" data-act="dec">−</button>
          <input class="qty-input mono" type="number" min="1" value="${l.cartons}" data-act="qty">
          <button class="qty-btn" data-act="inc">+</button>
        </div>
        <div style="text-align:left;">
          <div class="mono" style="font-weight:700;">${fmt.money(l.line_total)}</div>
          <div class="mono muted" style="font-size:11px;">${l.cartons} كرتون × ${l.carton_qty} = ${fmt.num(l.units)} قطعة</div>
        </div>
      </div>
    </div>`;
}

function escape(s='') { return s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]); }

/* ============ Interactions ============ */
els.toggle.addEventListener('click', () => openDrawer('cart-drawer'));

els.body.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-act]');
  if (!btn) return;
  const wrap = btn.closest('.cart-line');
  const id = wrap.dataset.id;
  const line = getState().cart.find(c => c.product_id === id);
  if (!line) return;

  if (btn.dataset.act === 'inc') updateCartLine(id, line.cartons + 1);
  if (btn.dataset.act === 'dec') updateCartLine(id, Math.max(0, line.cartons - 1));
  if (btn.dataset.act === 'remove') removeFromCart(id);
});

els.body.addEventListener('change', (e) => {
  const inp = e.target.closest('[data-act="qty"]');
  if (!inp) return;
  const id = inp.closest('.cart-line').dataset.id;
  const v = Math.max(0, Number(inp.value) || 0);
  updateCartLine(id, v);
});

$('#cart-clear').addEventListener('click', () => {
  if (getState().cart.length === 0) return;
  if (confirm('إفراغ السلة بالكامل؟')) clearCart();
});

els.checkout.addEventListener('click', () => {
  openModal('checkout-modal');
});

$('#checkout-confirm')?.addEventListener('click', () => {
  // In production: insert into `orders` + `order_items`, then clearCart
  toast('تم إرسال الطلب — سنتواصل معك خلال 24 ساعة', 'success');
  clearCart();
  closeModal('checkout-modal');
  closeDrawer('cart-drawer');
});

/* ============ Boot ============ */
subscribe(render);
loadCart();
