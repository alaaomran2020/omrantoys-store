/**
 * Tailwind config — Omran Trading Co. B2B Dashboard
 * Digital Brutalism • Dark Mode • RTL Arabic
 *
 * Note: the prototype ships with a hand-crafted CSS system in
 * `assets/css/brutalism.css` (single stylesheet, no build step) so the
 * static host works out of the box. This config is the *authoritative*
 * design-token source when the project is later ported into a build
 * pipeline (Vite / Next / Astro).
 */
module.exports = {
  content: ['./**/*.html', './assets/js/**/*.js'],
  darkMode: 'class',
  theme: {
    // Enforce brutalist edges — no soft radii allowed
    borderRadius: {
      none: '0px',
      DEFAULT: '2px',
      sm: '2px',
      md: '2px',
    },
    // Kill decorative shadows
    boxShadow: {
      none: 'none',
      DEFAULT: 'none',
      focus: '0 0 0 2px #005bf0',
    },
    extend: {
      colors: {
        bg: {
          0: '#0a0a0a',
          1: '#121212',
          2: '#1e1e1e',
          3: '#2a2a2a',
          4: '#383838',
        },
        fg: {
          0: '#ffffff',
          1: '#f5f5f5',
          2: '#a3a3a3',
          3: '#6b6b6b',
          4: '#525252',
        },
        accent: {
          DEFAULT: '#005bf0',
          hover:   '#0047c2',
          press:   '#003a9e',
        },
        danger:  '#ff3355',
        success: '#00d97a',
        warning: '#ffb800',
        border: {
          DEFAULT: '#2a2a2a',
          strong:  '#3f3f3f',
        },
      },
      fontFamily: {
        sans: ['"IBM Plex Sans Arabic"', 'Cairo', 'system-ui', 'sans-serif'],
        mono: ['"IBM Plex Mono"', '"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
      fontSize: {
        // Dense B2B scale
        '2xs': ['11px', '1.4'],
        xs:    ['12px', '1.5'],
        sm:    ['13px', '1.5'],
        base:  ['14px', '1.5'],
        lg:    ['16px', '1.4'],
        xl:    ['20px', '1.3'],
        '2xl': ['28px', '1.2'],
        '3xl': ['40px', '1.1'],
      },
      spacing: {
        // Match brutalism.css scale
        '0.5': '2px',
        '1':   '4px',
        '2':   '8px',
        '3':   '12px',
        '4':   '16px',
        '5':   '24px',
        '6':   '32px',
        '8':   '48px',
        '10':  '64px',
      },
    },
  },
  plugins: [],
};
