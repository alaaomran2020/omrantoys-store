# عُمران للتجارة — B2B Wholesale Dashboard

منصة الجملة الرقمية لشركة عمران للتجارة. HTML + Tailwind + Vanilla JS، جاهزة للربط مع Supabase.

## البنية

```
├── index.html              → صفحة تسجيل الدخول / إنشاء حساب
├── dashboard.html          → اللوحة الرئيسية (الأصناف + السلة + CRUD)
├── tailwind.config.js      → tokens التصميم (Digital Brutalism)
├── assets/
│   ├── css/brutalism.css   → نظام التصميم الكامل (single stylesheet)
│   └── js/
│       ├── supabase.js     → عميل Supabase + mock fallback
│       ├── state.js        → central store مع sync للـ DB
│       ├── auth.js         → منطق الدخول والتسجيل
│       ├── products.js     → CRUD + البحث + التصفية
│       ├── cart.js         → سلة الكراتين + إتمام الطلب
│       └── ui.js           → toast / modal / drawer helpers
└── README.md
```

## التشغيل المحلي

```bash
# أي static server يعمل
npx serve .
# أو
python3 -m http.server 8000
```

افتح `http://localhost:8000` — سيعمل في **وضع تجريبي** (البيانات محفوظة محلياً) حتى تربط Supabase.

## ربط Supabase

1. أنشئ مشروعاً جديداً في [app.supabase.com](https://app.supabase.com).
2. شغّل مخطط قاعدة البيانات التالي في SQL Editor:

```sql
-- المنتجات
create table products (
  id uuid primary key default gen_random_uuid(),
  sku text unique not null,
  name_ar text not null,
  category text not null,
  wholesale_price numeric not null check (wholesale_price >= 0),
  carton_qty integer not null check (carton_qty > 0),
  stock integer not null default 0 check (stock >= 0),
  image_url text,
  created_at timestamptz default now()
);

-- سلة كل مستخدم (persistent cart)
create table cart_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  product_id uuid references products(id) on delete cascade,
  cartons integer not null check (cartons > 0),
  unit_price numeric not null,
  created_at timestamptz default now(),
  unique (user_id, product_id)
);

-- الطلبيات
create table orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id),
  total numeric not null,
  status text not null default 'pending',
  created_at timestamptz default now()
);

-- RLS
alter table products enable row level security;
alter table cart_items enable row level security;
alter table orders enable row level security;

create policy "public read products" on products for select using (true);
create policy "user manages own cart" on cart_items for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "user reads own orders" on orders for select using (auth.uid() = user_id);
```

3. من إعدادات Supabase → API، انسخ `URL` و `anon key`.

4. أنشئ ملف `env.js` بجوار `index.html`:

```html
<!-- أضف هذا السطر في <head> قبل بقية السكربتات -->
<script>
  window.__ENV__ = {
    SUPABASE_URL: 'https://xxxx.supabase.co',
    SUPABASE_ANON_KEY: 'eyJhbGciOi...'
  };
</script>
```

بمجرد الربط، ستختفي شارة "وضع تجريبي" تلقائياً وستُحفظ البيانات في السحابة (**إصلاح Data Persistence bug**).

## الهوية البصرية

- **الخلفيات**: `#0a0a0a` / `#121212` / `#1e1e1e`
- **Accent**: `#005bf0` (Electric Blue) للإجراءات الأساسية فقط
- **الخطوط**: IBM Plex Sans Arabic + IBM Plex Mono للأرقام
- **الزوايا**: `0-2px` فقط — لا rounded كبيرة
- **الظلال**: ممنوعة — استخدم borders حادة للفصل

## المزايا المطبقة

| # | الميزة | الحالة |
|---|---|---|
| 1 | تسجيل دخول/تسجيل B2B (Supabase Auth) | ✅ |
| 2 | البحث الفوري (اسم + SKU) | ✅ |
| 3 | التصفية (فئة + حالة مخزون) | ✅ |
| 4 | سلة الكراتين + حساب فوري + حد أدنى | ✅ |
| 5 | CRUD منتجات كامل مع confirmation dialog | ✅ |
| 6 | Data sync عبر Supabase (بديل localStorage) | ✅ |
| 7 | Sidebar قابل للطي (data density) | ✅ |
| 8 | RTL كامل + Arabic UI | ✅ |
| 9 | Toast notifications + error handling | ✅ |

---

## سير عمل Git — الاستراتيجية المعتمدة

**الفرع لكل ميزة/إصلاح → Pull Request → مراجعة يدوية → دمج.**

### 1. إعداد أولي (مرة واحدة)

```bash
gh auth login                          # مصادقة GitHub CLI
git remote -v                          # تأكيد الـ remote
```

### 2. لكل ميزة/إصلاح جديد

```bash
# انطلق من main محدّث
git checkout main
git pull origin main

# فرع بمسمى واضح
git checkout -b feat/wholesale-cart
#         أو
git checkout -b fix/data-persistence

# ... اعمل التعديلات ...

git add .
git commit -m "feat(cart): B2B cart with carton math + min order rule

- Persistent state via Supabase cart_items table
- Real-time totals (cartons / units / SAR)
- Enforces minimum order threshold
- RTL drawer with sharp brutalist edges"

git push -u origin feat/wholesale-cart
```

### 3. فتح PR

```bash
gh pr create \
  --title "feat(cart): B2B wholesale cart module" \
  --body  "Implements features #3 from spec. Awaiting manual review." \
  --base  main \
  --head  feat/wholesale-cart
```

### 4. بعد المراجعة والموافقة

```bash
gh pr merge --squash --delete-branch
git checkout main
git pull origin main
```

### قواعد رسائل الـ commit (Conventional Commits)

| Prefix | متى نستخدمه |
|---|---|
| `feat:` | ميزة جديدة |
| `fix:` | إصلاح bug |
| `refactor:` | إعادة هيكلة بدون تغيير سلوك |
| `style:` | تعديلات CSS/تصميم فقط |
| `docs:` | تحديث توثيق |
| `chore:` | تحديث dependencies / build |

### سياسة الاختبار
- **تغييرات كبيرة** (feat, refactor): مطلوب تشغيل اختبار يدوي كامل قبل الـ PR.
- **تغييرات صغيرة** (style, docs, chore): commit مباشر بعد مراجعة ذاتية.

### سياسة الـ PR
🚫 **ممنوع الدمج التلقائي.**
✅ **كل PR ينتظر مراجعة يدوية قبل الدمج**.

---

**Copyright © 2026 Omran Trading Co. — All rights reserved.**
